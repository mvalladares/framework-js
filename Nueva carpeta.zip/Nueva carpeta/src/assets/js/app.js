//CSS
import '../scss/app.scss'; 

//JS
import $ from 'jquery'
import bootstrap from '../scss/addons/bootstrap-sass/assets/javascripts/bootstrap'
import './fn.js'